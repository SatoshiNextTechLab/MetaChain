function but1() {
    window.location.href = 'addland.html';
}
function but2() {
    window.location.href = 'addtree.html';
}
function but3() {
    window.location.href = 'seloption.html';
}
function but4() {
    window.location.href = 'ownreq.html';
}
function but5() {
    window.location.href = 'ship.html';
}

